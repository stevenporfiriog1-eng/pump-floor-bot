// Service worker minimo: permite instalar el panel como app. Siempre usa datos en vivo.
const CACHE = 'pump-floor-v1';
const SHELL = ['/icon-192.png', '/icon-512.png', '/apple-touch-icon.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL))); self.skipWaiting(); });
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.pathname === '/events') return;
  e.respondWith(fetch(e.request).catch(() => caches.match(e.request).then(r => r ||
    new Response('<meta name="viewport" content="width=device-width"><body style="background:#07140D;color:#E6F6EC;font:18px sans-serif;padding:30px">No se puede conectar con el bot. Revisa que la PC esté encendida y el bot abierto.</body>', { headers: { 'Content-Type': 'text/html; charset=utf-8' } }))));
});
