# The Pump Floor — bot de 6 agentes para pump.fun

Opera memecoins **reales** de pump.fun en vivo. Arranca en **modo práctica** (dinero simulado) y, cuando quieras, lo cambias a **modo real**.

## 1. Instalar (una sola vez)
1. Instala **Node.js LTS** desde https://nodejs.org (siguiente, siguiente, finalizar).
2. Descomprime esta carpeta en tu escritorio.

## 2. Modo práctica
Doble clic en **iniciar-practica.bat**.
- La primera vez instala lo necesario (1–2 minutos).
- Se abre el panel en tu navegador: http://localhost:3000
- Los tokens, compradores y precios son reales y en vivo. Las compras y ventas se calculan con la bonding curve real e incluyen comisiones, pero no se gasta dinero.
- Déjalo correr varias horas o días. Todo queda guardado en **trades.csv**.

## 3. Ajustes (config.json, ábrelo con el Bloc de notas)
| Ajuste | Qué hace |
|---|---|
| bancoInicialUsd | Banco de práctica (89) |
| metaUsd | Se detiene al llegar (5000) |
| modoProfit | "usd" = vende al ganar X dólares; "pct" = vende al llegar a un % |
| profitObjetivoUsd | Dólares de ganancia por trade para vender (10; pon 5 si quieres) |
| profitObjetivoPct | % para vender si modoProfit es "pct" (20) |
| puntajeMinimo | Puntaje de análisis (0-100) que debe tener un token para comprarlo (70) |
| stopLossPct | Vende si pierde este % (15) |
| reinvertirPct | % del banco que mete en cada trade (100) |
| maxSolPorTrade | Tope de SOL por trade |
| observarSegundos | Cuánto observa un token antes de decidir |
| minCompradoresUnicos / minVolumenCompraSol | Filtros de VETO |
| maxDevPct | Descarta si el creador compró más de este % |
| perdidaMaxPct | Deja de abrir trades si el banco cae este % |

Cierra la ventana negra y vuelve a abrir el .bat para aplicar cambios.

## 4. Modo real (solo cuando la práctica te convenza)
1. En Phantom crea una **wallet nueva solo para el bot** y pon poco SOL (lo que estés dispuesto a perder).
2. Exporta la clave privada de **esa** wallet (Phantom → Ajustes → Exportar clave privada).
3. Copia `.env.example`, renómbralo a `.env`, y pega la clave en `PRIVATE_KEY=`.
4. (Recomendado) Crea un RPC gratis en Helius o QuickNode y ponlo en `RPC_URL=`; el público es lento.
5. Doble clic en **iniciar-real.bat** y escribe `SI` para confirmar.

Seguridad:
- Nunca uses tu wallet principal ni compartas el archivo `.env` con nadie (ni lo subas a internet).
- El bot solo corre en tu computadora; el panel solo es visible desde tu PC.
- PumpPortal cobra ~0.5% por trade y pump.fun ~1%, además de las fees de red.
- Botón **Vender ya** en el panel para salir de una posición al instante. **Pausar** detiene compras nuevas.

## Lo que debes saber
Esta estrategia no garantiza ganancias. En pump.fun la mayoría de tokens caen o hacen rug, y llegar de $89 a $5,000 requiere unos 23 trades ganadores seguidos al +20%. Usa la práctica para ver tu win rate real antes de arriesgar dinero.

## 5. Verlo en tu celular, tablet u otra PC
El bot corre en tu computadora y los demás dispositivos ven el mismo panel en vivo (y pueden usar Pausar y Vender ya).

**En la misma red Wi-Fi de tu casa**
1. Al iniciar, la ventana negra muestra algo como `Desde tu celular (mismo Wi-Fi): http://192.168.1.25:3000` y un **PIN de 6 dígitos**.
2. Si Windows pregunta por el Firewall, marca **Redes privadas** y dale **Permitir acceso**.
3. En el celular abre esa dirección y escribe el PIN.
4. Para tenerlo como app: en iPhone, Safari → Compartir → **Agregar a inicio**. En Android, Chrome → menú ⋮ → **Agregar a pantalla de inicio**.

**Fuera de casa (datos móviles u otra red)**
Usa **Tailscale** (gratis, privado y seguro; no abre tu PC a internet):
1. Instala Tailscale en la PC y en el celular (tailscale.com) e inicia sesión con la misma cuenta en ambos.
2. En la app de Tailscale del celular verás la IP de tu PC (empieza con 100.).
3. Abre `http://ESA-IP:3000` en el celular y escribe el PIN.

No abras el puerto 3000 en tu router para verlo desde fuera: cualquiera en internet podría intentar entrar.

**Notas**
- La PC tiene que estar encendida y con el bot abierto. Para que no se duerma: Configuración → Sistema → Energía → Suspender: **Nunca**.
- El PIN se guarda en `config.json`. Si lo borras (dejas `"pin": ""`), se genera uno nuevo y los dispositivos tendrán que volver a entrar.
- Para que solo funcione en esta PC, pon `"permitirOtrosDispositivos": false`.
- Si quieres que funcione 24/7 sin tu PC, se puede instalar en un servidor (VPS); pídemelo y te armo la guía.

## 6. Usarlo como app

**En tu PC (Windows)**
- Doble clic en **crear-acceso-directo.bat** una sola vez. Aparece **The Pump Floor** en tu escritorio con su ícono.
- Ábrelo: el bot arranca minimizado y el panel se abre en su propia ventana, como una app (sin pestañas ni barra del navegador).

**En iPhone / iPad**
1. Abre la dirección del panel en **Safari** y pon el PIN.
2. Compartir → **Agregar a inicio**. Se abre en pantalla completa como app.

**En Android**
- En el mismo Wi-Fi: Chrome → ⋮ → **Agregar a pantalla de inicio** (acceso directo).
- Para la app instalable completa, Android exige conexión segura (https). Con Tailscale es gratis:
  1. En la PC abre una ventana de comandos (cmd) y escribe: `tailscale serve --bg 3000`
  2. Te dará una dirección como `https://tu-pc.tail1234.ts.net`. Ábrela en Chrome del celular y pon el PIN.
  3. Toca **Instalar app** en el panel (o ⋮ → **Instalar app**).
  Esta dirección funciona en casa y fuera de casa, y solo desde tus dispositivos de Tailscale.

El celular vibra cada vez que el bot cierra un trade mientras tienes la app abierta.

## 7. Retirar ganancias
1. Toca **Pausar** en el panel. Si hay una operación abierta, toca **Vender ya** y espera a que se venda.
2. Aparece el botón **Retirar**. Tócalo.
3. Toca **Solo profit** para sacar solo la ganancia (tu depósito sigue trabajando), escribe un monto, o toca **Todo**.
4. En modo real, pega la dirección de Solana a donde quieres enviar el dinero: tu Phantom principal o la dirección de depósito de SOL de tu exchange. La próxima vez ya aparece guardada.
5. Si lo haces desde el celular u otro dispositivo, escribe tu PIN.
6. Confirma. Verás el enlace de la transacción.

Revisa bien la dirección antes de confirmar: en la blockchain las transferencias no se pueden deshacer.
En modo práctica el retiro es simulado.

## 8. Inteligencia y protecciones
Antes de comprar, VETO revisa 8 señales (compradores, volumen, compras vs ventas, tendencia, punto de entrada, que no haya una ballena, redes sociales del token y % del dev) y da un puntaje de 0 a 100.
Descarta al instante si detecta: snipers/bundle en los primeros segundos, un comprador con demasiado volumen, un token que ya subió demasiado o que cae desde su máximo, que dejó de recibir compras, o un creador que ya hizo rug antes.

Protecciones automáticas (config.json):
| Ajuste | Qué hace |
|---|---|
| reinvertirPct | % del banco por trade (50). Menos = pierdes menos en un mal trade |
| stopLossPct | Pérdida máxima por trade (10) |
| maxPerdidasSeguidas / minutosEnfriamiento | Tras 3 pérdidas seguidas descansa 30 min |
| perdidaMaxDiaPct | Si el banco baja 15% en el día, deja de operar ese día |
| puntajeMinimo | 75. Sube solo +4 con cada pérdida y baja -2 con cada ganancia |
| segundosSinCompradoresTomar | Si ya ganó algo y no entran compradores en 40 s, toma la ganancia |
