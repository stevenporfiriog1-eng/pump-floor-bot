@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$s=(New-Object -ComObject WScript.Shell);" ^
 "$d=[Environment]::GetFolderPath('Desktop');" ^
 "$l=$s.CreateShortcut((Join-Path $d 'The Pump Floor.lnk'));" ^
 "$l.TargetPath='%~dp0iniciar-practica.bat';" ^
 "$l.WorkingDirectory='%~dp0';" ^
 "$l.IconLocation='%~dp0app\icon.ico';" ^
 "$l.WindowStyle=1;" ^
 "$l.Save()"
echo Listo: ya tienes "The Pump Floor" en tu escritorio.
pause
