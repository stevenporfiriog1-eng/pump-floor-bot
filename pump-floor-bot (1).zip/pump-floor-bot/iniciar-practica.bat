@echo off
chcp 65001 >nul
title The Pump Floor - PRACTICA
cd /d "%~dp0"
echo.
echo  ===== THE PUMP FLOOR - PRACTICA =====
echo.
echo "%~dp0" | find /i "\Temp\" >nul && (
  echo  [X] Estas abriendo el archivo DENTRO del zip.
  echo      Haz clic derecho en pump-floor-bot.zip ^> "Extraer todo", y abre el .bat desde la carpeta extraida.
  pause & exit /b
)
where node >nul 2>nul || (
  echo  [X] Falta instalar Node.js.
  echo      Se abrira la pagina de descarga: instala la version LTS, reinicia la PC y vuelve a abrir este archivo.
  start https://nodejs.org/es
  pause & exit /b
)
for /f "tokens=*" %%v in ('node -v') do echo  [OK] Node.js %%v
if not exist node_modules (
  echo  [..] Instalando dependencias, solo la primera vez. Tarda 1-3 minutos...
  call npm install --no-audit --no-fund || (
    echo  [X] No se pudieron instalar. Revisa tu conexion a internet y vuelve a intentar.
    pause & exit /b
  )
)
echo  [OK] Dependencias listas
echo  [..] Arrancando el bot. El panel se abrira solo cuando este listo.
echo.
start "" /min powershell -NoProfile -WindowStyle Hidden -Command "for($i=0;$i -lt 90;$i++){try{Invoke-WebRequest http://localhost:3000/manifest.json -UseBasicParsing -TimeoutSec 2 | Out-Null; Start-Process msedge '--app=http://localhost:3000'; break}catch{Start-Sleep 2}}"
node bot.js
echo.
echo  El bot se detuvo. Si ves un error arriba, tomale foto y mandala.
pause
