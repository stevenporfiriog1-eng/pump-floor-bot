// The Pump Floor - bot de 6 agentes para pump.fun
// Modo practica (por defecto): tokens y precios REALES, dinero simulado.
// Modo real: node bot.js --real  (usa la wallet del archivo .env)
import fs from 'fs';
import http from 'http';
import os from 'os';
import crypto from 'crypto';
import path from 'path';
import readline from 'readline';
import { fileURLToPath } from 'url';
import 'dotenv/config';
import WebSocket from 'ws';
import bs58 from 'bs58';
import { Connection, Keypair, VersionedTransaction, PublicKey, LAMPORTS_PER_SOL, SystemProgram, Transaction } from '@solana/web3.js';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const CFG_DEFECTO = {"puerto": 3000, "permitirOtrosDispositivos": true, "pin": "", "bancoInicialUsd": 89, "metaGananciaUsd": 50, "modoProfit": "usd", "profitObjetivoUsd": 5, "profitObjetivoPct": 20, "stopLossPct": 0, "puntajeMinimo": 75, "reinvertirPct": 50, "maxSolPorTrade": 0.5, "observarSegundos": 25, "minCompradoresUnicos": 12, "minVolumenCompraSol": 2, "maxDevPct": 10, "maxTokensObservando": 25, "maxMinutosEnPosicion": 6, "segundosSinTradesParaSalir": 90, "venderAlProgresoCurvaPct": 95, "comisionPct": 1.5, "slippagePct": 15, "priorityFeeSol": 0.0005, "reservaSolParaFees": 0.02, "perdidaMaxPct": 25, "solUsdRespaldo": 150, "pool": "pump", "direccionRetiro": "", "perdidaMaxDiaPct": 15, "maxPerdidasSeguidas": 3, "minutosEnfriamiento": 30, "segundosSinCompradoresTomar": 40, "usarRugCheck": true, "geminiModelo": "gemini-2.5-flash", "geminiRiesgoMax": 70, "solCaidaMaxPct": 3, "walletReal": "D7we1ffz6S5WkqhNCzLy4REoE1MojT33hZRwmeW7LhiU"};
let CFG; try { CFG = { ...CFG_DEFECTO, ...JSON.parse(fs.readFileSync(path.join(DIR, 'config.json'), 'utf8')) }; }
catch { CFG = { ...CFG_DEFECTO }; console.log('config.json no encontrado: uso la configuración por defecto'); }
process.on('unhandledRejection', e => console.log('Aviso (no detiene el bot):', e?.message || e));
process.on('uncaughtException', e => console.log('Error atrapado (el bot sigue):', e?.message || e));
// En servidor (Railway, etc.): puerto, PIN y carpeta de datos por variables de entorno
if (process.env.PORT) { CFG.puerto = Number(process.env.PORT); CFG.permitirOtrosDispositivos = true; }
if (/^\d{6}$/.test(process.env.PANEL_PIN || '')) CFG.pin = process.env.PANEL_PIN;
const DATA = process.env.DATA_DIR || DIR;
try { fs.mkdirSync(DATA, { recursive: true }); } catch { }
let LIVE = process.argv.includes('--real');
const TOTAL_SUPPLY = 1_000_000_000;
const V_SOL_INICIO = 30;        // SOL virtual con el que arranca la curva
const V_SOL_GRADUA = 115;       // aprox. SOL virtual al graduarse (aproximado)

// ---------- estado ----------
const S = {
  modo: LIVE ? 'REAL' : 'ENTRENAMIENTO',
  inicio: Date.now(),
  solUsd: CFG.solUsdRespaldo,
  bancoSol: 0, inicioSol: 0,
  trades: 0, ganados: 0,
  pos: null, hist: [],
  agentes: { scan: 'inactivo', vet: 'inactivo', size: 'inactivo', fill: 'inactivo', risk: 'inactivo', exit: 'inactivo' },
  activo: 'scan',
  log: [], observando: 0,
  pausado: false, terminado: false, ocupado: false, retiradoSol: 0, retirando: false,
  perdidasSeguidas: 0, enfriarHasta: 0, puntajeDinamico: 0, creadoresMalos: new Set(), inicioDia: Date.now(), bancoInicioDia: 0,
  wallet: null,
};
const watch = new Map(); // mint -> datos de observacion

function log(msg, tipo = '') {
  const t = new Date().toLocaleTimeString('es');
  S.log.unshift({ t, msg, tipo });
  if (S.log.length > 150) S.log.pop();
  console.log(`[${t}] ${msg.replace(/<[^>]+>/g, '')}`);
  emitir();
}
function agente(id, txt) { S.agentes[id] = txt; S.activo = id; emitir(); }
const usd = sol => sol * S.solUsd;
const fmtUsd = v => '$' + v.toFixed(2);
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ---------- precio SOL ----------
async function actualizarSolUsd() {
  try {
    const r = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd');
    const j = await r.json();
    if (j?.solana?.usd) { S.solUsd = j.solana.usd; (S.solHist || (S.solHist = [])).push({ t: Date.now(), p: S.solUsd }); S.solHist = S.solHist.filter(x => Date.now() - x.t < 2 * 3600000); }
  } catch { /* usa el respaldo */ }
}

// ---------- wallet (modo real) ----------
let conn = null, wallet = null;
async function balanceSol() { return (await conn.getBalance(wallet.publicKey)) / LAMPORTS_PER_SOL; }
async function balanceToken(mint) {
  const r = await conn.getParsedTokenAccountsByOwner(wallet.publicKey, { mint: new PublicKey(mint) });
  return r.value.reduce((a, acc) => a + (acc.account.data.parsed.info.tokenAmount.uiAmount || 0), 0);
}
async function esperarConfirmacion(sig) {
  for (let i = 0; i < 45; i++) {
    const st = (await conn.getSignatureStatuses([sig])).value[0];
    if (st?.err) throw new Error('La transaccion fallo en la red');
    if (st && (st.confirmationStatus === 'confirmed' || st.confirmationStatus === 'finalized')) return;
    await sleep(1500);
  }
  throw new Error('No se confirmo a tiempo');
}
async function tradeReal(action, mint, amount, enSol) {
  const r = await fetch('https://pumpportal.fun/api/trade-local', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      publicKey: wallet.publicKey.toBase58(), action, mint, amount,
      denominatedInSol: enSol ? 'true' : 'false',
      slippage: CFG.slippagePct, priorityFee: CFG.priorityFeeSol, pool: CFG.pool,
    }),
  });
  if (r.status !== 200) throw new Error(`PumpPortal respondio ${r.status}: ${await r.text()}`);
  const tx = VersionedTransaction.deserialize(new Uint8Array(await r.arrayBuffer()));
  tx.sign([wallet]);
  const sig = await conn.sendTransaction(tx, { maxRetries: 3 });
  await esperarConfirmacion(sig);
  return sig;
}

// ---------- matematica de la bonding curve ----------
function tokensPorSol(vS, vT, solNeto) { return vT - (vS * vT) / (vS + solNeto); }
function solPorTokens(vS, vT, tokens) { return vS - (vS * vT) / (vT + tokens); }
function cotizarVenta(p) {
  return solPorTokens(p.vS, p.vT, p.tokens) * (1 - CFG.comisionPct / 100);
}
const progresoCurva = vS => Math.max(0, Math.min(100, (vS - V_SOL_INICIO) / (V_SOL_GRADUA - V_SOL_INICIO) * 100));

// ---------- websocket de pump.fun ----------
let ws;
function wsSend(o) { if (ws?.readyState === 1) ws.send(JSON.stringify(o)); }
function conectar() {
  ws = new WebSocket('wss://pumpportal.fun/api/data');
  ws.on('open', () => {
    log('Conectado al feed en vivo de pump.fun');
    wsSend({ method: 'subscribeNewToken' });
    const keys = [...watch.keys(), ...(S.pos ? [S.pos.mint] : [])];
    if (keys.length) wsSend({ method: 'subscribeTokenTrade', keys });
  });
  ws.on('message', raw => { try { manejar(JSON.parse(raw)); } catch { } });
  ws.on('close', () => { log('Feed desconectado, reconectando en 3 s…', 'down'); setTimeout(conectar, 3000); });
  ws.on('error', () => { });
}

function manejar(m) {
  if (!m.mint) return;
  if (m.txType === 'create') return nuevoToken(m);
  if (m.txType !== 'buy' && m.txType !== 'sell') return;
  const w = watch.get(m.mint);
  if (w) {
    w.vS = m.vSolInBondingCurve; w.vT = m.vTokensInBondingCurve; w.ultimo = Date.now();
    guardarTrade(w.trades, m);
    if (w.vT > 0) { const pr = w.vS / w.vT; if (!w.p0) w.p0 = pr; w.h.push(+((pr / w.p0 - 1) * 100).toFixed(2)); if (w.h.length > 200) w.h.shift(); }
    if (m.txType === 'buy') {
      w.compradores.add(m.traderPublicKey); w.volCompra += m.solAmount || 0; w.ultimaCompra = Date.now();
      w.porComprador.set(m.traderPublicKey, (w.porComprador.get(m.traderPublicKey) || 0) + (m.solAmount || 0));
      if (Date.now() - w.creado < 3000) w.comprasRapidas++;
    } else { w.volVenta += m.solAmount || 0; if (m.traderPublicKey === w.creador) { w.devVendio = true; S.creadoresMalos.add(w.creador); } }
  }
  const p = S.pos;
  if (p && p.mint === m.mint) {
    p.vS = m.vSolInBondingCurve; p.vT = m.vTokensInBondingCurve; p.ultimo = Date.now();
    if (m.txType === 'sell' && m.traderPublicKey === p.creador) { p.devVendio = true; S.creadoresMalos.add(p.creador); }
    if (m.txType === 'buy') p.ultimaCompra = Date.now();
    guardarTrade(p.trades || (p.trades = []), m);
    revisarPosicion();
  }
}

function nuevoToken(m) {
  if (S.pausado || S.terminado || S.pos || S.ocupado || enfriando() || bloqueadoPorPerdida()) return;
  agente('scan', 'escaneando');
  if (watch.size >= CFG.maxTokensObservando) return;
  if (S.creadoresMalos.has(m.traderPublicKey)) { log(`SCOUT ignoró $${m.symbol}: creador con rug previo`, 'down'); return; }
  const devPct = (m.initialBuy || 0) / TOTAL_SUPPLY * 100;
  watch.set(m.mint, {
    mint: m.mint, nombre: m.name, simbolo: m.symbol, creador: m.traderPublicKey,
    creado: Date.now(), ultimo: Date.now(), devPct,
    vS: m.vSolInBondingCurve, vT: m.vTokensInBondingCurve,
    compradores: new Set(), volCompra: 0, volVenta: 0, devVendio: false, porComprador: new Map(), comprasRapidas: 0, trades: [], aprobado: false, ultimaCompra: Date.now(), redes: null,
    p0: m.vTokensInBondingCurve > 0 ? m.vSolInBondingCurve / m.vTokensInBondingCurve : 0, h: [0],
  });
  S.observando = watch.size;
  wsSend({ method: 'subscribeTokenTrade', keys: [m.mint] });
  revisarRedes(m.mint, m.uri);
  log(`SCOUT encontró <b>$${m.symbol}</b> (${m.name}) · dev ${devPct.toFixed(1)}%`);
}

// ---------- HERRAMIENTA 1: filtro del mercado de SOL ----------
function solCayendo() {
  const h = S.solHist || []; if (h.length < 3) return null;
  const hace1h = h.find(x => Date.now() - x.t <= 3600000) || h[0];
  const cambio = (S.solUsd / hace1h.p - 1) * 100;
  return cambio <= -CFG.solCaidaMaxPct ? cambio : null;
}
// ---------- HERRAMIENTA 2: RugCheck (seguridad del token, gratis, sin clave) ----------
const RIESGOS_GRAVES = ['mint authority', 'freeze authority', 'top 10 holders', 'single holder', 'rugged', 'copycat', 'high ownership', 'insider'];
async function rugcheck(mint) {
  if (!CFG.usarRugCheck) return { ok: true, txt: 'apagado' };
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 6000);
    const r = await fetch(`https://api.rugcheck.xyz/v1/tokens/${mint}/report/summary`, { signal: ctl.signal }); clearTimeout(t);
    if (!r.ok) return { ok: true, txt: `sin datos (${r.status})` };
    const j = await r.json(); const riesgos = j.risks || [];
    const graves = riesgos.filter(x => x.level === 'danger' && RIESGOS_GRAVES.some(k => String(x.name || '').toLowerCase().includes(k)));
    const nombres = riesgos.map(x => x.name).slice(0, 3).join(', ');
    return { ok: !graves.length, txt: graves.length ? `PELIGRO: ${graves.map(x => x.name).join(', ')}` : `ok · riesgo ${j.score_normalised ?? j.score ?? '?'}${nombres ? ' · ' + nombres : ''}` };
  } catch { return { ok: true, txt: 'no respondió' }; }
}
// ---------- HERRAMIENTA 3: opinión de la IA Gemini de Google (opcional) ----------
async function opinionGemini(w, a) {
  const key = (process.env.GEMINI_API_KEY || '').trim();
  if (!key) return { ok: true, txt: 'sin clave (opcional)' };
  const prompt = `Eres un analista de riesgo de memecoins de pump.fun. Responde SOLO un JSON {"riesgo":0-100,"opinion":"máx 12 palabras en español"}.
Token: ${w.nombre} ($${w.simbolo}). Compradores únicos: ${a.buyers}. Compra/venta: ${a.ratio.toFixed(1)}x. Momentum: ${a.mom.toFixed(0)}%. Dev compró: ${w.devPct.toFixed(1)}%. Redes sociales: ${w.redes ?? 0}/3. Un comprador tiene ${(a.ballena * 100).toFixed(0)}% del volumen. Puntaje del bot: ${a.total}/100.`;
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 8000);
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${CFG.geminiModelo}:generateContent?key=${key}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: ctl.signal,
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.2, responseMimeType: 'application/json' } }) });
    clearTimeout(t);
    const j = await r.json(); const txt = j?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const o = JSON.parse(txt.replace(/```json|```/g, '').trim());
    const riesgo = Number(o.riesgo);
    return { ok: !(riesgo >= CFG.geminiRiesgoMax), txt: `riesgo ${riesgo}/100 · ${o.opinion || ''}` };
  } catch { return { ok: true, txt: 'no respondió' }; }
}
async function verificarYComprar(w, a) {
  S.ocupado = true;
  try {
    agente('vet', 'RugCheck + IA');
    const [rc, ia] = await Promise.all([rugcheck(w.mint), opinionGemini(w, a)]);
    if (S.analisis && S.analisis.simbolo === '$' + w.simbolo) { S.analisis.rugcheck = rc.txt; S.analisis.ia = ia.txt; }
    log(`RugCheck $${w.simbolo}: ${rc.txt} · IA Gemini: ${ia.txt}`, rc.ok && ia.ok ? 'up' : 'down');
    if (!rc.ok || !ia.ok) {
      if (S.analisis) { S.analisis.aprobado = false; S.analisis.alertas = [!rc.ok ? 'RugCheck: ' + rc.txt : 'IA Gemini: ' + ia.txt, ...S.analisis.alertas]; }
      dejarDeObservar(w.mint); return;
    }
  } finally { S.ocupado = false; }
  comprar(w);
}

// ---------- SEÑAL: detecta si va a subir o a bajar ----------
function senal(h, trades) {
  if (!h || h.length < 6) return { score: 50, estado: 'LATERAL' };
  const n = h.length, k = Math.min(10, n - 1), slope = (h[n - 1] - h[n - 1 - k]) / k;
  const ema = (arr, a) => arr.reduce((e, v, i) => i ? e + a * (v - e) : v, 0), fast = ema(h.slice(-12), .45), slow = ema(h.slice(-30), .12);
  let s = 50 + Math.max(-25, Math.min(25, slope * 6)) + Math.max(-15, Math.min(15, (fast - slow) * 2));
  if (trades && trades.length) {
    const now = Date.now(), rec = trades.filter(t => now - t.t < 30000), prev = trades.filter(t => now - t.t >= 30000 && now - t.t < 60000);
    const bv = rec.filter(t => t.buy).reduce((a, t) => a + t.sol, 0), sv = rec.filter(t => !t.buy).reduce((a, t) => a + t.sol, 0);
    const accel = rec.filter(t => t.buy).length - prev.filter(t => t.buy).length;
    const ventaGrande = rec.some(t => !t.buy && t.sol > Math.max(0.8, bv * 0.3));
    s += Math.max(-15, Math.min(15, (bv / (sv + 0.05) - 1) * 4)) + Math.max(-10, Math.min(10, accel * 1.5)) - (ventaGrande ? 20 : 0);
  }
  s = Math.round(Math.max(0, Math.min(100, s)));
  return { score: s, estado: s >= 65 ? 'SUBIENDO' : s <= 35 ? 'BAJANDO' : 'LATERAL' };
}
const senalTxt = p => p.estado === 'SUBIENDO' ? `▲ Subiendo · fuerza ${p.score}` : p.estado === 'BAJANDO' ? `▼ Bajando · fuerza ${p.score}` : `◆ Lateral · fuerza ${p.score}`;
function guardarTrade(arr, m) { arr.push({ t: Date.now(), buy: m.txType === 'buy', sol: m.solAmount || 0 }); if (arr.length > 300) arr.shift(); }

// ---------- revisar redes sociales (metadata del token) ----------
async function revisarRedes(mint, uri) {
  const w = watch.get(mint); if (!w || !uri) { if (w) w.redes = 0; return; }
  try {
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 4000);
    const j = await (await fetch(uri, { signal: ctl.signal })).json(); clearTimeout(t);
    w.redes = ['twitter', 'telegram', 'website'].filter(k => typeof j[k] === 'string' && j[k].startsWith('http')).length;
  } catch { if (watch.get(mint)) watch.get(mint).redes = 0; }
}

// ---------- VETO: decide despues de observar ----------
function dejarDeObservar(mint) {
  watch.delete(mint); S.observando = watch.size;
  if (!S.pos || S.pos.mint !== mint) wsSend({ method: 'unsubscribeTokenTrade', keys: [mint] });
}
function analizar(w) {
  const buyers = w.compradores.size, vol = w.volCompra, ratio = w.volCompra / (w.volVenta + 0.01);
  const h = w.h, mom = h.length > 1 ? h[h.length - 1] : 0, curva = progresoCurva(w.vS);
  const rec = h.slice(-8), subiendo = rec.length > 3 && rec[rec.length - 1] > rec[0];
  const pico = Math.max(...h), desdePico = mom - pico;           // cuanto ha caido desde el maximo
  const ballena = Math.max(0, ...w.porComprador.values()) / (vol || 1); // % del volumen de un solo comprador
  const quieto = (Date.now() - w.ultimaCompra) / 1000;
  const p = {
    compradores: Math.min(20, buyers * 20 / 25),
    volumen: Math.min(15, vol * 15 / 6),
    presion: Math.max(0, Math.min(15, (ratio - 1) * 6)),
    tendencia: subiendo ? 15 : 0,
    entrada: mom >= 5 && mom <= 60 && desdePico > -25 ? 10 : 0,   // subiendo pero sin estar inflado
    reparto: ballena < 0.2 ? 10 : ballena < 0.3 ? 5 : 0,           // compras repartidas, no una ballena
    redes: w.redes >= 2 ? 10 : w.redes === 1 ? 5 : 0,
    dev: w.devPct < 3 ? 5 : w.devPct < 6 ? 3 : 0,
  };
  const total = Math.round(Object.values(p).reduce((a, v) => a + v, 0));
  const alertas = [];
  if (w.comprasRapidas >= 6) alertas.push(`${w.comprasRapidas} compras en los primeros 3 s (snipers/bundle)`);
  if (ballena >= 0.35) alertas.push(`un solo comprador tiene ${(ballena * 100).toFixed(0)}% del volumen`);
  if (mom > 120) alertas.push(`ya subió ${mom.toFixed(0)}%, muy tarde para entrar`);
  if (desdePico < -35) alertas.push(`cayó ${(-desdePico).toFixed(0)}% desde su máximo`);
  if (quieto > 12) alertas.push(`sin compras hace ${quieto.toFixed(0)} s`);
  if (curva > 70) alertas.push('curva muy avanzada');
  return { total, buyers, ratio, mom, ballena, redes: w.redes, alertas, p };
}
function puntajeExigido() { return Math.min(95, CFG.puntajeMinimo + S.puntajeDinamico); }
function enfriando() { return Date.now() < S.enfriarHasta; }
function evaluar() {
  const ahora = Date.now();
  for (const w of watch.values()) {
    if (ahora - w.creado < CFG.observarSegundos * 1000) continue;
    agente('vet', 'analizando');
    let motivo = null;
    if (w.devPct > CFG.maxDevPct) motivo = `el dev compró ${w.devPct.toFixed(1)}%`;
    else if (w.devVendio) motivo = 'el dev ya vendió';
    else if (w.compradores.size < CFG.minCompradoresUnicos) motivo = `solo ${w.compradores.size} compradores`;
    else if (w.volCompra < CFG.minVolumenCompraSol) motivo = `poco volumen (${w.volCompra.toFixed(2)} SOL)`;
    const a = analizar(w);
    if (!motivo && a.alertas.length) motivo = a.alertas[0];
    if (!motivo && a.total < puntajeExigido()) motivo = `puntaje ${a.total}/100 (mínimo ${puntajeExigido()})`;
    S.analisis = { simbolo: '$' + w.simbolo, total: a.total, exigido: puntajeExigido(), p: a.p, alertas: motivo ? [motivo, ...a.alertas.filter(x => x !== motivo)] : a.alertas, aprobado: !motivo && !S.pos && !S.ocupado };
    if (!motivo && !S.pos && !S.ocupado) {
      const sg = senal(w.h, w.trades);
      if (sg.estado !== 'SUBIENDO') {
        if (!w.aprobado) { w.aprobado = true; log(`VETO aprobó $${w.simbolo} (${a.total}/100); SCOUT espera señal de subida… ahora ${senalTxt(sg)}`); }
        if (ahora - w.creado < (CFG.observarSegundos + 60) * 1000) { agente('scan', 'esperando señal'); continue; }
        motivo = 'nunca dio señal de subida';
      } else log(`SCOUT detectó subida en $${w.simbolo}: ${senalTxt(sg)} → comprar`, 'up');
    }
    if (motivo || S.pos || S.ocupado || S.pausado || S.terminado || bloqueadoPorPerdida() || enfriando()) {
      if (motivo) log(`VETO descartó $${w.simbolo}: ${motivo}`, 'down');
      dejarDeObservar(w.mint);
      continue;
    }
    const solMal = solCayendo();
    if (solMal != null) { log(`Mercado: SOL cayó ${solMal.toFixed(1)}% en 1 h, los agentes no compran por ahora`, 'down'); dejarDeObservar(w.mint); continue; }
    log(`VETO aprobó <b>$${w.simbolo}</b> · puntaje <b>${a.total}/100</b> · ${a.buyers} compradores · compra/venta ${a.ratio.toFixed(1)}x · momentum ${a.mom >= 0 ? '+' : ''}${a.mom.toFixed(0)}% · redes ${a.redes ?? 0}/3`, 'up');
    verificarYComprar(w, a);
    break;
  }
}

function bloqueadoPorPerdida() {
  if (Date.now() - S.inicioDia > 86400000) { S.inicioDia = Date.now(); S.bancoInicioDia = totalSol(); }
  const total = totalSol() + S.retiradoSol;
  return total < S.inicioSol * (1 - CFG.perdidaMaxPct / 100) || totalSol() < S.bancoInicioDia * (1 - CFG.perdidaMaxDiaPct / 100);
}
function totalSol() { return S.bancoSol + (S.pos ? cotizarVenta(S.pos) : 0); }

// ---------- SIZE + FILL ----------
async function comprar(w) {
  S.ocupado = true;
  try {
    agente('size', 'calculando');
    let sol = Math.min(S.bancoSol * CFG.reinvertirPct / 100, CFG.maxSolPorTrade);
    if (LIVE) sol = Math.min(sol, S.bancoSol);
    if (sol < 0.005) { log('SIZE: banco muy pequeño para operar', 'down'); dejarDeObservar(w.mint); return; }
    log(`SIZE mete ${sol.toFixed(4)} SOL (${fmtUsd(usd(sol))}) en el trade; vuelve al vender`);
    agente('fill', 'comprando');
    let tokens, costo, sig = null;
    if (LIVE) {
      const antes = await balanceSol();
      sig = await tradeReal('buy', w.mint, Number(sol.toFixed(4)), true);
      await sleep(1500);
      tokens = await balanceToken(w.mint);
      costo = antes - await balanceSol();
      if (!tokens) throw new Error('No se recibieron tokens');
    } else {
      tokens = tokensPorSol(w.vS, w.vT, sol * (1 - CFG.comisionPct / 100));
      costo = sol;
    }
    S.bancoSol -= costo;
    S.pos = {
      mint: w.mint, nombre: w.nombre, simbolo: w.simbolo, creador: w.creador,
      tokens, costo, vS: w.vS, vT: w.vT, entrada: Date.now(), ultimo: Date.now(), devVendio: false, vendiendo: false,
    };
    S.hist = [0]; guardarEstado();
    log(`FILL compró <b>$${w.simbolo}</b> por ${costo.toFixed(4)} SOL (${fmtUsd(usd(costo))})${sig ? ` · <a href="https://solscan.io/tx/${sig}" target="_blank">tx</a>` : ''}`, 'up');
    watch.delete(w.mint); S.observando = watch.size;
  } catch (e) {
    log(`FILL falló: ${e.message}`, 'down');
    dejarDeObservar(w.mint);
  } finally { S.ocupado = false; emitir(); }
}

// ---------- RISK + EXIT ----------
function pnlPct(p) { return cotizarVenta(p) / p.costo - 1; }
const REGLA_COBRO_USD = 20; // regla fija: al llegar a $20 de profit total, vende y cobra
const metaTradeSol = p => CFG.modoProfit === 'usd' ? CFG.profitObjetivoUsd / S.solUsd : p.costo * CFG.profitObjetivoPct / 100;
function revisarPosicion() {
  const p = S.pos; if (!p || p.vendiendo) return;
  const pct = pnlPct(p) * 100;
  S.hist.push(+pct.toFixed(2)); if (S.hist.length > 300) S.hist.shift();
  agente(pct < 0 ? 'risk' : 'exit', 'vigilando');
  const min = (Date.now() - p.entrada) / 60000, quieto = (Date.now() - p.ultimo) / 1000;
  const gan = cotizarVenta(p) - p.costo, meta = metaTradeSol(p), conStop = CFG.stopLossPct > 0;
  p.maxGan = Math.max(p.maxGan || 0, gan);
  const ganBase = usd(S.bancoSol + cotizarVenta(p) - S.baseSol);
  if (ganBase >= REGLA_COBRO_USD) return vender(`💰 Regla $20: la ganancia llegó a ${fmtUsd(ganBase)}, vendido`);
  if (gan < 0 && !conStop) agente('risk', 'esperando que suba');
  if (gan >= meta) return vender(`EXIT vendió con +${fmtUsd(usd(gan))} de ganancia`);
  const sg = senal(S.hist, p.trades);
  if (gan > 0 && (Date.now() - p.entrada) > 8000 && sg.estado === 'BAJANDO') return vender(`EXIT detectó que va a bajar (${senalTxt(sg)}): aseguró +${fmtUsd(usd(gan))}`);
  if (p.maxGan >= meta * 0.6 && gan > 0 && gan <= meta * 0.2) return vender(`EXIT aseguró +${fmtUsd(usd(gan))} antes de que se perdiera`);
  if (gan > 0 && gan >= meta * 0.4 && (Date.now() - (p.ultimaCompra || p.entrada)) / 1000 > CFG.segundosSinCompradoresTomar) return vender(`EXIT tomó +${fmtUsd(usd(gan))}: ya no entran compradores`);
  if (gan > 0 && progresoCurva(p.vS) >= CFG.venderAlProgresoCurvaPct) return vender(`EXIT vendió con +${fmtUsd(usd(gan))} antes de la graduación`);
  if (!conStop) return emitir();
  if (pct <= -CFG.stopLossPct) return vender(`RISK activó el stop-loss (${pct.toFixed(1)}%)`);
  if (p.devVendio) return vender('RISK vendió: el dev está vendiendo');
  if (min >= CFG.maxMinutosEnPosicion) return vender('EXIT salió por tiempo');
  if (quieto >= CFG.segundosSinTradesParaSalir) return vender('EXIT salió: el token se quedó sin trades');
  emitir();
}
async function vender(motivo) {
  const p = S.pos; if (!p || p.vendiendo) return;
  p.vendiendo = true;
  agente(motivo.startsWith('RISK') ? 'risk' : 'exit', 'vendiendo');
  try {
    let recibido, sig = null;
    if (LIVE) {
      const antes = await balanceSol();
      sig = await tradeReal('sell', p.mint, '100%', false);
      await sleep(1500);
      recibido = await balanceSol() - antes;
    } else recibido = cotizarVenta(p);
    S.bancoSol += recibido;
    const pnl = recibido - p.costo;
    S.trades++; if (pnl > 0) S.ganados++;
    if (pnl > 0) { S.perdidasSeguidas = 0; S.puntajeDinamico = Math.max(0, S.puntajeDinamico - 2); }
    else {
      S.perdidasSeguidas++; S.puntajeDinamico = Math.min(20, S.puntajeDinamico + 4);
      if (S.perdidasSeguidas >= CFG.maxPerdidasSeguidas) {
        S.enfriarHasta = Date.now() + CFG.minutosEnfriamiento * 60000; S.perdidasSeguidas = 0;
        setTimeout(() => log(`⏸️ ${CFG.maxPerdidasSeguidas} pérdidas seguidas: los agentes descansan ${CFG.minutosEnfriamiento} min y ahora exigen puntaje ${puntajeExigido()}`, 'down'), 50);
      }
    }
    log(`${motivo} · $${p.simbolo} · ${pnl >= 0 ? '+' : ''}${fmtUsd(usd(pnl))} → banco ${fmtUsd(usd(S.bancoSol))}${sig ? ` · <a href="https://solscan.io/tx/${sig}" target="_blank">tx</a>` : ''}`, pnl >= 0 ? 'up' : 'down');
    fs.appendFileSync(path.join(DATA, 'trades.csv'),
      `${new Date().toISOString()},${S.modo},${p.simbolo},${p.mint},${p.costo.toFixed(5)},${recibido.toFixed(5)},${(pnl / p.costo * 100).toFixed(2)}%\n`);
    wsSend({ method: 'unsubscribeTokenTrade', keys: [p.mint] });
    S.ultimo = { simbolo: p.simbolo, hist: S.hist.slice(-200), pct: pnl / p.costo * 100 };
    S.pos = null; guardarEstado();
    if (usd(S.bancoSol - S.baseSol) >= REGLA_COBRO_USD) {
      const g = S.bancoSol - S.baseSol; S.baseSol = S.bancoSol;
      log(`💰 Regla $20: +${fmtUsd(usd(g))} asegurados · nuevo monto ${fmtUsd(usd(S.bancoSol))}`, 'win');
    }
    if (usd(S.bancoSol + S.retiradoSol - S.inicioSol - (S.metaDesdeSol || 0)) >= CFG.metaGananciaUsd) {
      S.terminado = true;
      log(`🏁 Meta alcanzada: ganaste ${fmtUsd(usd(S.bancoSol + S.retiradoSol - S.inicioSol - (S.metaDesdeSol || 0)))}. Toca "Iniciar meta nueva" para seguir.`, 'win');
    } else if (bloqueadoPorPerdida()) {
      log(`Límite de pérdida (${CFG.perdidaMaxPct}%) alcanzado. No se abrirán más trades.`, 'down');
    } else log('Recomprando: SCOUT busca el siguiente token…');
  } catch (e) {
    p.vendiendo = false;
    log(`La venta falló: ${e.message}. Reintentando en 5 s…`, 'down');
    setTimeout(() => vender(motivo), 5000);
  }
  emitir();
}

// ---------- saldo de tu cartera real (solo lectura) ----------
async function actualizarSaldoReal() {
  if (!CFG.walletReal) return;
  try {
    const c = conn || new Connection(process.env.RPC_URL || 'https://api.mainnet-beta.solana.com', 'confirmed');
    S.saldoRealSol = (await c.getBalance(new PublicKey(CFG.walletReal))) / LAMPORTS_PER_SOL; emitir();
  } catch { }
}

// ---------- GUARDADO: nada se borra al cerrar o reiniciar ----------
const estadoPath = () => path.join(DATA, `estado-${LIVE ? 'real' : 'practica'}.json`);
function guardarEstado() {
  try {
    const p = S.pos ? { ...S.pos, trades: undefined } : null;
    fs.writeFileSync(estadoPath(), JSON.stringify({ wallet: S.wallet, inicioSol: S.inicioSol, baseSol: S.baseSol, bancoSol: S.bancoSol, trades: S.trades, ganados: S.ganados,
      retiradoSol: S.retiradoSol, puntajeDinamico: S.puntajeDinamico, metaDesdeSol: S.metaDesdeSol || 0, terminado: S.terminado, log: S.log.slice(0, 120), hist: S.hist.slice(-200), pos: p, guardado: Date.now() }));
  } catch { }
}
async function cargarEstado() {
  let e; try { e = JSON.parse(fs.readFileSync(estadoPath(), 'utf8')); } catch { return false; }
  if (LIVE && e.wallet && e.wallet !== S.wallet) return false;
  Object.assign(S, { inicioSol: e.inicioSol, baseSol: e.baseSol ?? e.inicioSol, trades: e.trades || 0, ganados: e.ganados || 0, retiradoSol: e.retiradoSol || 0,
    puntajeDinamico: e.puntajeDinamico || 0, log: e.log || [], hist: e.hist || [], metaDesdeSol: e.metaDesdeSol || 0, terminado: !!e.terminado });
  if (!LIVE) S.bancoSol = e.bancoSol;
  if (e.pos) {
    let tokens = e.pos.tokens;
    if (LIVE) { try { tokens = await balanceToken(e.pos.mint); } catch { tokens = 0; } }
    if (tokens > 0) { S.pos = { ...e.pos, tokens, trades: [], vendiendo: false, ultimo: Date.now() }; log(`📂 Trade recuperado: $${S.pos.simbolo}, el bot lo sigue vigilando`, 'win'); }
  }
  return true;
}

// ---------- CAMBIAR DE MODO DESDE EL PANEL ----------
function limpiarSesion() {
  Object.assign(S, { trades: 0, ganados: 0, retiradoSol: 0, log: [], hist: [], pos: null, metaDesdeSol: 0, terminado: false,
    puntajeDinamico: 0, perdidasSeguidas: 0, enfriarHasta: 0, analisis: null, ultimo: null, pausado: false });
}
function guardarClave(clave) {
  const envPath = path.join(DIR, '.env'); let lineas = [];
  try { lineas = fs.readFileSync(envPath, 'utf8').split(/\r?\n/).filter(l => l && !l.startsWith('PRIVATE_KEY=')); } catch { }
  if (!lineas.some(l => l.startsWith('RPC_URL='))) lineas.push('RPC_URL=https://api.mainnet-beta.solana.com');
  fs.writeFileSync(envPath, ['PRIVATE_KEY=' + clave, ...lineas].join('\n') + '\n'); process.env.PRIVATE_KEY = clave;
}
async function activarReal({ clave, sol }, local) {
  if (LIVE) throw new Error('Ya estás en modo real');
  if (S.pos || S.ocupado) throw new Error('Hay un trade abierto: toca Cobrar primero y luego cambia de modo');
  let k = String(clave || '').trim();
  if (k && !local) throw new Error('Por seguridad, la clave privada solo se puede pegar desde la PC donde corre el bot');
  if (!k) k = (process.env.PRIVATE_KEY || '').trim();
  if (!k || k.startsWith('pega_aqui')) throw new Error('Falta la clave privada de tu cartera');
  let kp; try { kp = Keypair.fromSecretKey(bs58.decode(k)); } catch { throw new Error('Esa clave privada no es válida'); }
  if (CFG.walletReal && kp.publicKey.toBase58() !== CFG.walletReal) throw new Error(`Esa clave es de otra cartera (${kp.publicKey.toBase58().slice(0, 4)}…). Usa la de ${CFG.walletReal.slice(0, 4)}…${CFG.walletReal.slice(-4)}`);
  const c = new Connection(process.env.RPC_URL || 'https://api.mainnet-beta.solana.com', 'confirmed');
  const bal = (await c.getBalance(kp.publicKey)) / LAMPORTS_PER_SOL, disp = bal - CFG.reservaSolParaFees;
  if (disp <= 0.005) throw new Error(`Tu cartera tiene ${bal.toFixed(4)} SOL. Deposita SOL y vuelve a intentar`);
  let usar = Number(sol) > 0 ? Math.min(Number(sol), disp) : disp;
  if (clave) guardarClave(k);
  guardarEstado();
  LIVE = true; wallet = kp; conn = c; S.modo = 'REAL'; S.wallet = kp.publicKey.toBase58(); CFG.maxSolPorTrade = Math.max(CFG.maxSolPorTrade, usar);
  limpiarSesion(); S.bancoSol = usar; S.inicioSol = usar; S.baseSol = usar;
  if (await cargarEstado()) { S.bancoSol = usar; if (S.baseSol > usar) S.baseSol = usar; }
  S.bancoInicioDia = totalSol();
  log(`🔴 MODO REAL activado · cartera ${S.wallet.slice(0, 4)}…${S.wallet.slice(-4)} · usando ${usar.toFixed(4)} SOL (${fmtUsd(usd(usar))})`, 'win');
  guardarEstado(); return { ok: true, modo: 'REAL', usarUsd: usd(usar) };
}
async function activarEntrenamiento() {
  if (!LIVE) throw new Error('Ya estás en modo entrenamiento');
  if (S.pos || S.ocupado) throw new Error('Hay un trade abierto: toca Cobrar primero y luego cambia de modo');
  guardarEstado();
  LIVE = false; wallet = null; S.modo = 'ENTRENAMIENTO'; S.wallet = null;
  limpiarSesion(); S.bancoSol = CFG.bancoInicialUsd / S.solUsd; S.inicioSol = S.bancoSol; S.baseSol = S.bancoSol;
  await cargarEstado(); S.bancoInicioDia = totalSol();
  log('🟢 Modo entrenamiento activado · dinero simulado', 'win'); guardarEstado(); return { ok: true, modo: 'ENTRENAMIENTO' };
}

// ---------- RETIRAR ----------
async function cerrarYCobrar({ destino }) {
  S.pausado = true; log('Bot en pausa: cerrando el trade para cobrar');
  if (S.pos) {
    await vender('💸 Retiro: cerraste el trade');
    for (let i = 0; i < 40 && S.pos; i++) await sleep(500);
    if (S.pos) throw new Error('No se pudo vender todavía; el bot sigue reintentando. Vuelve a intentar en un momento.');
  }
  S.baseSol = S.bancoSol;
  log(`💸 Cobrado · nuevo monto ${fmtUsd(usd(S.bancoSol))}`, 'win');
  if (LIVE && String(destino || '').trim() && S.bancoSol - S.inicioSol > 0) return retirar({ profit: true, destino });
  return { ok: true, sol: 0, usd: 0, nuevoMonto: true, bancoUsd: usd(S.bancoSol), gananciaUsd: usd(S.bancoSol + S.retiradoSol - S.inicioSol) };
}
async function retirar({ montoUsd, todo, profit, destino, auto }) {
  if (!auto && !S.pausado) throw new Error('Pausa el bot antes de retirar');
  if (!auto && (S.pos || S.ocupado)) throw new Error('Hay una operación abierta: usa "Vender ya" primero');
  if (S.retirando) throw new Error('Ya hay un retiro en proceso');
  let sol = profit ? S.bancoSol - S.inicioSol : todo ? S.bancoSol : Number(montoUsd) / S.solUsd;
  if (profit && !(sol > 0)) throw new Error('Todavía no hay profit para retirar');
  if (!(sol > 0)) throw new Error('Monto inválido');
  if (sol > S.bancoSol + 1e-9) throw new Error(`Solo hay ${fmtUsd(usd(S.bancoSol))} disponibles`);
  S.retirando = true; emitir();
  try {
    let sig = null;
    if (LIVE && !String(destino || '').trim()) {
      // sin destino: el profit se queda en tu wallet y el bot ya no lo usa
    } else if (LIVE) {
      let to; try { to = new PublicKey(String(destino || '').trim()); } catch { throw new Error('Dirección de destino inválida'); }
      if (to.equals(wallet.publicKey)) throw new Error('El destino es la misma wallet del bot');
      const bal = await conn.getBalance(wallet.publicKey);
      let lamports = Math.floor(sol * LAMPORTS_PER_SOL);
      lamports = Math.min(lamports, bal - 10000);
      if (lamports <= 0) throw new Error('Saldo insuficiente para cubrir la comisión de red');
      const tx = new Transaction().add(SystemProgram.transfer({ fromPubkey: wallet.publicKey, toPubkey: to, lamports }));
      sig = await conn.sendTransaction(tx, [wallet]);
      await esperarConfirmacion(sig);
      sol = lamports / LAMPORTS_PER_SOL;
      CFG.direccionRetiro = to.toBase58();
      const c = JSON.parse(fs.readFileSync(path.join(DIR, 'config.json'), 'utf8')); c.direccionRetiro = CFG.direccionRetiro;
      fs.writeFileSync(path.join(DIR, 'config.json'), JSON.stringify(c, null, 2));
    }
    S.bancoSol = Math.max(0, S.bancoSol - sol);
    S.retiradoSol += sol;
    fs.appendFileSync(path.join(DATA, 'trades.csv'), `${new Date().toISOString()},${S.modo},RETIRO,${destino || '-'},${sol.toFixed(5)},,\n`);
    log(`${auto ? '💰 Regla $20: profit cobrado' : '💸 Retiro de'} ${sol.toFixed(4)} SOL (${fmtUsd(usd(sol))})${sig ? ` a ${String(destino).slice(0, 4)}…${String(destino).trim().slice(-4)} · <a href="https://solscan.io/tx/${sig}" target="_blank">tx</a>` : LIVE ? ' (queda en tu wallet, el bot ya no lo usa)' : ' (simulado)'}`, 'win');
    return { ok: true, sol, usd: usd(sol), sig, bancoUsd: usd(S.bancoSol) };
  } finally { S.retirando = false; emitir(); }
}

// ---------- panel local ----------
const clientes = new Set();
let pendiente = false;
function estadoPublico() {
  const p = S.pos;
  return {
    modo: S.modo, wallet: S.wallet, tieneClave: !!(process.env.PRIVATE_KEY || '').trim() && !(process.env.PRIVATE_KEY || '').startsWith('pega_aqui'), reservaSol: CFG.reservaSolParaFees, walletReal: CFG.walletReal || '', saldoRealSol: S.saldoRealSol ?? null, uptime: Date.now() - S.inicio, solUsd: S.solUsd,
    totalUsd: usd(totalSol()), inicioUsd: usd(S.inicioSol), bancoUsd: usd(S.bancoSol),
    modoProfit: CFG.modoProfit, tpUsd: CFG.profitObjetivoUsd, profitUsd: Math.max(0, usd(S.bancoSol - S.inicioSol)),
    metaUsd: CFG.metaGananciaUsd, metaDesdeUsd: usd(S.metaDesdeSol || 0), retiradoUsd: usd(S.retiradoSol), bancoSol: S.bancoSol, destinoRetiro: CFG.direccionRetiro || '', retirando: S.retirando, tp: CFG.profitObjetivoPct, sl: CFG.stopLossPct,
    trades: S.trades, ganados: S.ganados, agentes: S.agentes, activo: S.activo,
    observando: S.observando, pausado: S.pausado, enfriando: enfriando() ? Math.ceil((S.enfriarHasta - Date.now()) / 60000) : 0, puntajeExigido: puntajeExigido(), terminado: S.terminado,
    pos: p ? { simbolo: p.simbolo, nombre: p.nombre, mint: p.mint, costoUsd: usd(p.costo), valorUsd: usd(cotizarVenta(p)), pct: pnlPct(p) * 100, tpPct: metaTradeSol(p) / p.costo * 100, senal: senalTxt(senal(S.hist, p.trades)), curva: progresoCurva(p.vS), seg: Math.round((Date.now() - p.entrada) / 1000) } : null,
    hist: S.hist.slice(-150), log: S.log.slice(0, 80),
    radar: (() => { let best = null; for (const w of watch.values()) if (w.h.length > 1 && (!best || w.compradores.size > best.compradores.size)) best = w;
      return best ? { simbolo: best.simbolo, hist: best.h.slice(-150), compradores: best.compradores.size, senal: senalTxt(senal(best.h, best.trades)) } : null; })(),
    ultimo: S.ultimo || null, analisis: S.analisis || null,
  };
}
function emitir() {
  if (pendiente) return; pendiente = true;
  setTimeout(() => {
    pendiente = false;
    const data = `data: ${JSON.stringify(estadoPublico())}\n\n`;
    for (const res of clientes) res.write(data);
  }, 300);
}
// --- acceso desde otros dispositivos (celular, tablet, otra PC) ---
if (CFG.permitirOtrosDispositivos && !/^\d{6}$/.test(String(CFG.pin || ''))) {
  if (process.env.PORT) console.log('⚠️ Pon la variable PANEL_PIN (6 dígitos) en tu servidor para que el PIN no cambie.');
  CFG.pin = String(crypto.randomInt(100000, 1000000));
  try { const c = JSON.parse(fs.readFileSync(path.join(DIR, 'config.json'), 'utf8')); c.pin = CFG.pin; fs.writeFileSync(path.join(DIR, 'config.json'), JSON.stringify(c, null, 2)); } catch { }
}
const SESION = crypto.createHash('sha256').update('pump-floor:' + CFG.pin + ':' + DIR).digest('hex').slice(0, 32); // sigue valida al reiniciar; cambia si cambias el PIN
const esLocal = req => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress) && !req.headers['x-forwarded-for'];
const tieneSesion = req => (req.headers.cookie || '').split(';').some(c => c.trim() === 'pf=' + SESION);
const intentos = new Map();
function paginaPin(error) {
  return `<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>The Pump Floor</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#07140D;color:#E6F6EC;font:16px "Segoe UI",system-ui,sans-serif}
form{border:2px solid #1D4430;background:#0E2418;padding:24px;width:min(320px,90vw)}h1{font:800 26px Consolas,monospace;color:#5BF08A;margin:0 0 12px}
input{width:100%;font:700 28px Consolas,monospace;letter-spacing:8px;text-align:center;padding:10px;background:#07140D;color:#E6F6EC;border:2px solid #1D4430;margin:8px 0}
button{width:100%;font:700 16px Consolas,monospace;padding:12px;border:0;background:#5BF08A;color:#04130A}p{color:#FF4F8B;margin:6px 0 0}</style></head>
<body><form method="POST" action="/login"><h1>The Pump Floor</h1><label for="pin">PIN de 6 dígitos</label>
<input id="pin" name="pin" inputmode="numeric" maxlength="6" autocomplete="off" autofocus><button>Entrar</button>${error ? `<p>${error}</p>` : ''}</form></body></html>`;
}
const MANIFEST = JSON.stringify({ id: '/', name: 'The Pump Floor', short_name: 'Pump Floor', description: 'Bot de 6 agentes para pump.fun',
  start_url: '/', scope: '/', display: 'standalone', orientation: 'any', background_color: '#07140D', theme_color: '#07140D',
  icons: [{ src: '/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any maskable' }, { src: '/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }] });
const ARCHIVOS_APP = { '/sw.js': 'application/javascript', '/icon-192.png': 'image/png', '/icon-512.png': 'image/png', '/apple-touch-icon.png': 'image/png', '/icon.ico': 'image/x-icon' };
const ICON = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="#07140D"/><rect x="12" y="34" width="8" height="18" fill="#5BF08A"/><rect x="28" y="24" width="8" height="28" fill="#5BF08A"/><rect x="44" y="12" width="8" height="40" fill="#FFD24A"/></svg>';

http.createServer((req, res) => {
  if (req.url === '/manifest.json') { res.writeHead(200, { 'Content-Type': 'application/manifest+json' }); return res.end(MANIFEST); }
  if (ARCHIVOS_APP[req.url]) {
    const f = [path.join(DIR, 'app', req.url.slice(1)), path.join(DIR, req.url.slice(1))].find(x => fs.existsSync(x));
    if (!f) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { 'Content-Type': ARCHIVOS_APP[req.url], 'Service-Worker-Allowed': '/' }); return res.end(fs.readFileSync(f));
  }
  if (req.url === '/icon.svg') { res.writeHead(200, { 'Content-Type': 'image/svg+xml' }); return res.end(ICON); }
  if (!esLocal(req) && !tieneSesion(req)) {
    if (req.method === 'POST' && req.url === '/login') {
      const ip = req.socket.remoteAddress, n = intentos.get(ip) || { c: 0, hasta: 0 };
      if (Date.now() < n.hasta) { res.writeHead(429, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(paginaPin('Demasiados intentos. Espera 5 minutos.')); }
      let body = ''; req.on('data', d => { body += d; if (body.length > 200) req.destroy(); });
      req.on('end', () => {
        const pin = new URLSearchParams(body).get('pin');
        if (pin === String(CFG.pin)) {
          intentos.delete(ip);
          res.writeHead(302, { 'Set-Cookie': `pf=${SESION}; HttpOnly; SameSite=Strict; Path=/; Max-Age=2592000`, Location: '/' });
          log(`Nuevo dispositivo conectado al panel (${ip.replace('::ffff:', '')})`);
          return res.end();
        }
        n.c++; if (n.c >= 5) { n.hasta = Date.now() + 5 * 60000; n.c = 0; } intentos.set(ip, n);
        res.writeHead(401, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(paginaPin('PIN incorrecto.'));
      });
      return;
    }
    if (req.url === '/events') { res.writeHead(401); return res.end(); }
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(paginaPin());
  }
  if (req.url === '/events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    clientes.add(res); res.write(`data: ${JSON.stringify(estadoPublico())}\n\n`);
    req.on('close', () => clientes.delete(res)); return;
  }
  if (req.method === 'POST' && req.url === '/pausar') {
    if (S.terminado) {
      S.terminado = false; S.pausado = false; S.metaDesdeSol = totalSol() + S.retiradoSol - S.inicioSol;
      log(`🎯 Meta nueva: ganar ${fmtUsd(CFG.metaGananciaUsd)} más desde tu monto de ${fmtUsd(usd(totalSol()))}`, 'win'); guardarEstado(); res.end('ok'); return;
    }
    S.pausado = !S.pausado; log(S.pausado ? 'Bot en pausa: no abrirá trades nuevos' : 'Bot reanudado');
    res.end('ok'); return;
  }
  if (req.method === 'POST' && req.url === '/modo') {
    let body = ''; req.on('data', d => { body += d; if (body.length > 3000) req.destroy(); });
    req.on('end', async () => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      try {
        const q = JSON.parse(body || '{}');
        if (!esLocal(req) && String(q.pin) !== String(CFG.pin)) throw new Error('PIN incorrecto');
        res.end(JSON.stringify(q.modo === 'real' ? await activarReal(q, esLocal(req)) : await activarEntrenamiento()));
      } catch (e) { res.end(JSON.stringify({ ok: false, error: e.message })); }
    });
    return;
  }
  if (req.method === 'POST' && req.url === '/retirar') {
    let body = ''; req.on('data', d => { body += d; if (body.length > 2000) req.destroy(); });
    req.on('end', async () => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      try {
        const q = JSON.parse(body || '{}');
        if (!esLocal(req) && String(q.pin) !== String(CFG.pin)) throw new Error('PIN incorrecto');
        res.end(JSON.stringify(q.cerrarYCobrar ? await cerrarYCobrar(q) : await retirar(q)));
      } catch (e) { res.end(JSON.stringify({ ok: false, error: e.message })); }
    });
    return;
  }
  if (req.method === 'POST' && req.url === '/vender') {
    if (S.pos) vender('Venta manual'); res.end('ok'); return;
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  try { res.end(fs.readFileSync(path.join(DIR, 'dashboard.html'))); } catch { res.end('<h1>Falta dashboard.html</h1><p>Sube el archivo dashboard.html al repositorio.</p>'); }
}).listen(CFG.puerto, CFG.permitirOtrosDispositivos ? '0.0.0.0' : '127.0.0.1');

function direccionesRed() {
  return Object.values(os.networkInterfaces()).flat().filter(i => i && i.family === 'IPv4' && !i.internal).map(i => i.address);
}

// ---------- arranque ----------
function preguntar(q) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(r => rl.question(q, a => { rl.close(); r(a.trim()); }));
}
async function main() {
  await actualizarSolUsd();
  setInterval(actualizarSolUsd, 2 * 60 * 1000);
  if (LIVE) {
    let clave = (process.env.PRIVATE_KEY || '').trim();
    if (!clave || clave.startsWith('pega_aqui')) {
      console.log('\nConecta tu wallet de Solana (Phantom o la de pump.fun).');
      console.log('Copia la CLAVE PRIVADA de tu wallet y pégala aquí (clic derecho = pegar).');
      clave = await preguntar('Clave privada: ');
    }
    try { wallet = Keypair.fromSecretKey(bs58.decode(clave.trim())); }
    catch { console.log('\nEsa clave no es válida. Copia la clave privada completa y vuelve a abrir.'); process.exit(1); }
    if (CFG.walletReal && wallet.publicKey.toBase58() !== CFG.walletReal) {
      console.log(`\n❌ Esa clave privada es de otra cartera (${wallet.publicKey.toBase58()}).\n   Tu cartera de pump.fun es ${CFG.walletReal}. Exporta la clave de ESA cartera y vuelve a abrir.`);
      try { fs.unlinkSync(path.join(DIR, '.env')); } catch { }
      process.exit(1);
    }
    const envPath = path.join(DIR, '.env');
    const rpc = process.env.RPC_URL || 'https://api.mainnet-beta.solana.com';
    if (!process.env.PRIVATE_KEY || process.env.PRIVATE_KEY.startsWith('pega_aqui'))
      fs.writeFileSync(envPath, `PRIVATE_KEY=${clave.trim()}\nRPC_URL=${rpc}\n`);
    conn = new Connection(rpc, 'confirmed');
    const bal = await balanceSol();
    S.wallet = wallet.publicKey.toBase58();
    console.log(`\n⚠️  MODO REAL — wallet ${S.wallet}`);
    console.log(`    Balance: ${bal.toFixed(4)} SOL (${fmtUsd(bal * S.solUsd)})`);
    if (bal <= CFG.reservaSolParaFees) { console.log('\nTu wallet no tiene SOL. Deposita SOL en esa wallet y vuelve a abrir.'); process.exit(1); }
    const disponible = bal - CFG.reservaSolParaFees;
    const resp = await preguntar(`\n¿Cuántos SOL quieres que use el bot? (Enter = todo, ${disponible.toFixed(4)} SOL): `);
    let usar = resp ? parseFloat(resp.replace(',', '.')) : disponible;
    if (!(usar > 0)) usar = disponible;
    usar = Math.min(usar, disponible);
    CFG.maxSolPorTrade = Math.max(CFG.maxSolPorTrade, usar);
    console.log(`    El bot usará ${usar.toFixed(4)} SOL (${fmtUsd(usar * S.solUsd)}) y reinvertirá las ganancias.`);
    const ok = await preguntar('\nEscribe SI para operar con dinero real: ');
    if (ok.toUpperCase() !== 'SI') { console.log('Cancelado.'); process.exit(0); }
    S.bancoSol = usar;
    S.limiteSol = usar;
  } else {
    S.bancoSol = CFG.bancoInicialUsd / S.solUsd;
  }
  const usar = S.bancoSol;
  S.inicioSol = S.bancoSol; S.baseSol = S.bancoSol;
  if (await cargarEstado()) {
    if (LIVE) { S.bancoSol = usar; if (S.baseSol > S.bancoSol + (S.pos ? S.pos.costo : 0)) S.baseSol = S.bancoSol; }
    log(`📂 Sesión recuperada · monto ${fmtUsd(usd(totalSol()))} · ${S.trades} trades · empezaste con ${fmtUsd(usd(S.inicioSol))}`, 'win');
  }
  S.bancoInicioDia = totalSol();
  setInterval(guardarEstado, 5000);
  actualizarSaldoReal(); setInterval(actualizarSaldoReal, 60000);
  process.on('SIGINT', () => { guardarEstado(); process.exit(0); });
  log(`Modo ${S.modo} · banco ${fmtUsd(usd(S.bancoSol))} · meta ganar ${fmtUsd(CFG.metaGananciaUsd)} · vende al ganar ${CFG.modoProfit === 'usd' ? fmtUsd(CFG.profitObjetivoUsd) : '+' + CFG.profitObjetivoPct + '%'} · puntaje mínimo ${CFG.puntajeMinimo}/100`);
  console.log(`\nPanel en esta PC: http://localhost:${CFG.puerto}`);
  if (CFG.permitirOtrosDispositivos) {
    for (const ip of direccionesRed()) console.log(`Desde tu celular (mismo Wi-Fi): http://${ip}:${CFG.puerto}`);
    console.log(`PIN para otros dispositivos: ${CFG.pin}\n`);
  }
  conectar();
  setInterval(() => { evaluar(); if (S.pos) revisarPosicion(); }, 1000);
}
main();
